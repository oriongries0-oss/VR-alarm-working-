[app]
title = VR Alarm
package.name = vralarm
package.domain = org.vralarm
source.dir = .
source.include_exts = py
version = 0.1
requirements = python3,kivy,plyer
orientation = landscape
fullscreen = 0
android.permissions = VIBRATE,WAKE_LOCK
android.api = 33
android.minapi = 24
android.archs = arm64-v8a

[buildozer]
log_level = 2
warn_on_root = 1
