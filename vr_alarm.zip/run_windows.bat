@echo off
python --version >nul 2>&1
if errorlevel 1 (
  echo Python is not installed. Get it from python.org and tick "Add python.exe to PATH".
  pause
  exit /b
)
python vr_alarm_simple.py
if errorlevel 1 pause
