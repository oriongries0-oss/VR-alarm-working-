VR ALARM
========
Two alarms:
  - "Get OFF VR in (min)"  -> countdown from now
  - "Play VR at (24h)"     -> alarm at a clock time (HH:MM)
When one fires: screen flashes, beeps, vibrates. DISMISS or SNOOZE 5 MIN.

TRY IT ON PC (30 seconds)
  pip install kivy plyer
  python main.py

BUILD THE APK (Linux, WSL, or Google Colab)
  pip install buildozer cython
  buildozer android debug
  -> APK appears in ./bin/

INSTALL ON QUEST
  1. Turn on Developer Mode (Meta Horizon phone app > Devices > Developer Mode)
  2. Install SideQuest on PC, plug in headset, drag the APK in
     (or:  adb install bin/vralarm-0.1-arm64-v8a_armeabi-v7a-debug.apk)
  3. In headset: Library > Unknown Sources > VR Alarm

IMPORTANT LIMIT
  Quest closes/pauses 2D apps when you launch a fullscreen VR game, so the
  alarm may NOT ring mid-game. For reliable alerts, run this same main.py on
  your PC (for PCVR) or use the phone/watch alarm alongside it.

EASIEST APK BUILD (no setup)
  Option A - GitHub: make a free repo, upload ALL files from this zip (keep the
  .github folder), open the Actions tab, run "Build APK", then download
  "vr-alarm-apk" from the finished run.
  Option B - Colab: follow colab_build.txt

PY FILE WON'T OPEN? USE THE SIMPLE VERSION
  Windows: double-click run_windows.bat
  Mac/Linux: ./run_mac_linux.sh   (or: python3 vr_alarm_simple.py)
  Needs only Python from python.org (tick "Add python.exe to PATH").
  main.py is the Kivy/Android version and needs: pip install kivy plyer
