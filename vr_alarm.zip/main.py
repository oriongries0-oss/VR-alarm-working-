"""VR Alarm - reminds you when to PLAY VR and when to GET OFF VR.
Runs on Android/Quest (built to APK with buildozer) and on desktop (python main.py).
"""
import math, os, struct, time, wave, datetime
from kivy.app import App
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.graphics import Color, Rectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput

BIG = "34sp"


def make_beep(path):
    """Generate a 1-second 'beep beep' wav so no asset files are needed."""
    rate = 22050
    frames = bytearray()
    for part in range(2):
        for i in range(int(rate * 0.3)):
            v = int(32000 * math.sin(2 * math.pi * 880 * i / rate))
            frames += struct.pack("<h", v)
        frames += b"\x00\x00" * int(rate * 0.2)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(bytes(frames))


class VRAlarm(App):
    def build(self):
        self.alarms = []        # {"at": epoch, "kind": "off"|"play"}
        self.ringing = None
        self.flash_on = False
        beep = os.path.join(self.user_data_dir, "beep.wav")
        make_beep(beep)
        self.sound = SoundLoader.load(beep)
        if self.sound:
            self.sound.loop = True

        self.root_box = BoxLayout(orientation="vertical", padding=30, spacing=20)
        with self.root_box.canvas.before:
            self.bg_color = Color(0.08, 0.08, 0.14, 1)
            self.bg = Rectangle()
        self.root_box.bind(pos=self._upd_bg, size=self._upd_bg)

        self.status = Label(text="No alarms set", font_size="28sp", halign="center")
        self.root_box.add_widget(self.status)

        row1 = BoxLayout(spacing=15)
        self.mins = TextInput(text="60", hint_text="minutes", multiline=False,
                              input_filter="int", font_size=BIG)
        row1.add_widget(Label(text="Get OFF VR in (min):", font_size="24sp"))
        row1.add_widget(self.mins)
        row1.add_widget(Button(text="START", font_size=BIG, on_release=self.start_off))
        self.root_box.add_widget(row1)

        row2 = BoxLayout(spacing=15)
        self.clock_in = TextInput(text="18:00", hint_text="HH:MM", multiline=False,
                                  font_size=BIG)
        row2.add_widget(Label(text="Play VR at (24h):", font_size="24sp"))
        row2.add_widget(self.clock_in)
        row2.add_widget(Button(text="SET", font_size=BIG, on_release=self.set_play))
        self.root_box.add_widget(row2)

        self.root_box.add_widget(Button(text="Cancel all alarms", font_size="24sp",
                                        on_release=self.cancel_all))

        self.ring_box = BoxLayout(spacing=15, size_hint_y=None, height=0, opacity=0)
        self.ring_box.add_widget(Button(text="DISMISS", font_size=BIG, on_release=self.dismiss))
        self.ring_box.add_widget(Button(text="SNOOZE 5 MIN", font_size=BIG, on_release=self.snooze))
        self.root_box.add_widget(self.ring_box)

        Clock.schedule_interval(self.tick, 0.5)
        return self.root_box

    def _upd_bg(self, *a):
        self.bg.pos = self.root_box.pos
        self.bg.size = self.root_box.size

    # ---- creating alarms ----
    def start_off(self, *a):
        try:
            m = int(self.mins.text)
        except ValueError:
            return
        self.alarms = [x for x in self.alarms if x["kind"] != "off"]
        self.alarms.append({"at": time.time() + m * 60, "kind": "off"})

    def set_play(self, *a):
        try:
            h, m = [int(x) for x in self.clock_in.text.split(":")]
            now = datetime.datetime.now()
            t = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if t <= now:
                t += datetime.timedelta(days=1)
        except Exception:
            self.status.text = "Use HH:MM, like 18:30"
            return
        self.alarms = [x for x in self.alarms if x["kind"] != "play"]
        self.alarms.append({"at": t.timestamp(), "kind": "play"})

    def cancel_all(self, *a):
        self.alarms = []
        self.dismiss()

    # ---- ticking / ringing ----
    def tick(self, dt):
        now = time.time()
        if not self.ringing:
            for a in list(self.alarms):
                if a["at"] <= now:
                    self.alarms.remove(a)
                    self.ring(a)
                    return
            if not self.alarms:
                self.status.text = "No alarms set"
            else:
                lines = []
                for a in sorted(self.alarms, key=lambda x: x["at"]):
                    left = int(a["at"] - now)
                    label = "Get OFF VR" if a["kind"] == "off" else "Play VR"
                    lines.append("%s in %d:%02d:%02d" % (label, left // 3600, left % 3600 // 60, left % 60))
                self.status.text = "\n".join(lines)
        else:
            self.flash_on = not self.flash_on
            self.bg_color.rgba = (0.9, 0.1, 0.1, 1) if self.flash_on else (0.1, 0.1, 0.5, 1)
            try:
                from plyer import vibrator
                vibrator.vibrate(0.3)
            except Exception:
                pass

    def ring(self, alarm):
        self.ringing = alarm
        self.status.text = ("TAKE THE HEADSET OFF!" if alarm["kind"] == "off"
                            else "TIME TO PLAY VR!")
        self.status.font_size = "48sp"
        self.ring_box.height, self.ring_box.opacity = 120, 1
        if self.sound:
            self.sound.play()

    def dismiss(self, *a):
        self.ringing = None
        if self.sound:
            self.sound.stop()
        self.bg_color.rgba = (0.08, 0.08, 0.14, 1)
        self.status.font_size = "28sp"
        self.ring_box.height, self.ring_box.opacity = 0, 0

    def snooze(self, *a):
        kind = self.ringing["kind"] if self.ringing else "off"
        self.dismiss()
        self.alarms.append({"at": time.time() + 300, "kind": kind})


if __name__ == "__main__":
    VRAlarm().run()
