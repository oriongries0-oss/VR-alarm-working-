"""VR Alarm (simple version) - needs ONLY Python. No installs, no Kivy."""
import time, datetime
import tkinter as tk
try:
    import winsound
except ImportError:
    winsound = None


class VRAlarm:
    def __init__(self, root):
        self.root = root
        root.title("VR Alarm")
        root.geometry("620x420")
        self.bg = "#14142a"
        root.configure(bg=self.bg)
        self.alarms = []
        self.ringing = None
        self.flash = False

        self.status = tk.Label(root, text="No alarms set", font=("Arial", 18),
                               fg="white", bg=self.bg, justify="center")
        self.status.pack(pady=20)

        f1 = tk.Frame(root, bg=self.bg); f1.pack(pady=8)
        tk.Label(f1, text="Get OFF VR in (min):", fg="white", bg=self.bg,
                 font=("Arial", 14)).pack(side="left")
        self.mins = tk.Entry(f1, width=6, font=("Arial", 16)); self.mins.insert(0, "60")
        self.mins.pack(side="left", padx=8)
        tk.Button(f1, text="START", font=("Arial", 13), command=self.start_off).pack(side="left")

        f2 = tk.Frame(root, bg=self.bg); f2.pack(pady=8)
        tk.Label(f2, text="Play VR at (HH:MM 24h):", fg="white", bg=self.bg,
                 font=("Arial", 14)).pack(side="left")
        self.clock = tk.Entry(f2, width=7, font=("Arial", 16)); self.clock.insert(0, "18:00")
        self.clock.pack(side="left", padx=8)
        tk.Button(f2, text="SET", font=("Arial", 13), command=self.set_play).pack(side="left")

        tk.Button(root, text="Cancel all alarms", command=self.cancel_all).pack(pady=8)

        self.ring_frame = tk.Frame(root, bg=self.bg)
        tk.Button(self.ring_frame, text="DISMISS", font=("Arial", 18), width=12,
                  command=self.dismiss).pack(side="left", padx=10)
        tk.Button(self.ring_frame, text="SNOOZE 5 MIN", font=("Arial", 18), width=12,
                  command=self.snooze).pack(side="left", padx=10)

        self.tick()

    def start_off(self):
        try:
            m = int(self.mins.get())
        except ValueError:
            return
        self.alarms = [a for a in self.alarms if a["kind"] != "off"]
        self.alarms.append({"at": time.time() + m * 60, "kind": "off"})

    def set_play(self):
        try:
            h, m = [int(x) for x in self.clock.get().split(":")]
            now = datetime.datetime.now()
            t = now.replace(hour=h, minute=m, second=0, microsecond=0)
            if t <= now:
                t += datetime.timedelta(days=1)
        except Exception:
            self.status.config(text="Use HH:MM, like 18:30")
            return
        self.alarms = [a for a in self.alarms if a["kind"] != "play"]
        self.alarms.append({"at": t.timestamp(), "kind": "play"})

    def cancel_all(self):
        self.alarms = []
        self.dismiss()

    def set_bg(self, color):
        self.root.configure(bg=color)
        for w in (self.status, self.ring_frame):
            w.configure(bg=color)

    def tick(self):
        now = time.time()
        if self.ringing:
            self.flash = not self.flash
            self.set_bg("#dd1111" if self.flash else "#1111aa")
            if winsound:
                winsound.Beep(880, 250)
            else:
                self.root.bell()
        else:
            for a in list(self.alarms):
                if a["at"] <= now:
                    self.alarms.remove(a)
                    self.ring(a)
                    break
            else:
                if not self.alarms:
                    self.status.config(text="No alarms set")
                else:
                    lines = []
                    for a in sorted(self.alarms, key=lambda x: x["at"]):
                        s = int(a["at"] - now)
                        name = "Get OFF VR" if a["kind"] == "off" else "Play VR"
                        lines.append("%s in %d:%02d:%02d" % (name, s // 3600, s % 3600 // 60, s % 60))
                    self.status.config(text="\n".join(lines))
        self.root.after(500, self.tick)

    def ring(self, alarm):
        self.ringing = alarm
        self.status.config(text="TAKE THE HEADSET OFF!" if alarm["kind"] == "off"
                           else "TIME TO PLAY VR!", font=("Arial", 28, "bold"))
        self.ring_frame.pack(pady=15)
        self.root.lift()
        self.root.attributes("-topmost", True)

    def dismiss(self):
        self.ringing = None
        self.set_bg(self.bg)
        self.status.config(font=("Arial", 18))
        self.ring_frame.pack_forget()
        self.root.attributes("-topmost", False)

    def snooze(self):
        kind = self.ringing["kind"] if self.ringing else "off"
        self.dismiss()
        self.alarms.append({"at": time.time() + 300, "kind": kind})


if __name__ == "__main__":
    root = tk.Tk()
    VRAlarm(root)
    root.mainloop()
