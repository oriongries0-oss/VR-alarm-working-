#!/bin/sh
cd "$(dirname "$0")"
python3 vr_alarm_simple.py
